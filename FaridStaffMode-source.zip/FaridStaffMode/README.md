# FaridStaffMode

Paper plugin source project built around the supplied `staff-mode.yml`.

## Build
Requires JDK 25+ and Maven:
```bash
mvn clean package
```
The resulting jar is in `target/FaridStaffMode-1.0.0.jar`.

## Install
1. Put the JAR in the server `plugins/` directory.
2. Start the server once; the supplied config is copied as `plugins/FaridStaffMode/config.yml`.
3. Restart or run `/staffmodeadmin reload` after editing the config.
4. Grant `faridcore.staff.mode` and the relevant feature permissions.

## Commands
- `/staffmode` (aliases `/staff`, `/sm`) toggle staff mode
- `/staffmode on|off`
- `/staffmodeadmin reload`

## Requested command integrations
- Vanish item dispatches the external `/sv` command. Install a vanish plugin that provides `/sv`.
- Random teleport executes `minecraft:tp @r` exactly as requested.
- Freeze is implemented internally; it does not depend on another plugin.

## Compatibility note
The project targets Paper API `26.3.build` and Java 25, matching PaperMC's current project setup guidance.
