package com.faridgame.faridstaffmode;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.context.Context;
import net.luckperms.api.context.ContextCalculator;
import net.luckperms.api.context.ContextConsumer;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public final class FaridStaffMode extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Set<UUID> staffMode = new HashSet<>();
    private final Set<UUID> vanished = new HashSet<>();
    private final Set<UUID> frozen = new HashSet<>();
    private final Set<UUID> betterView = new HashSet<>();
    private final Set<UUID> spectator = new HashSet<>();
    private final Map<UUID, ItemStack[]> savedContents = new HashMap<>();
    private final Map<UUID, ItemStack[]> savedArmor = new HashMap<>();
    private final Map<UUID, ItemStack> savedOffhand = new HashMap<>();
    private final Map<UUID, GameMode> savedModes = new HashMap<>();
    private final Map<UUID, Boolean> savedFlight = new HashMap<>();
    private final Map<UUID, Float> savedWalk = new HashMap<>();
    private final Map<UUID, Location> frozenLocations = new HashMap<>();
    private final NamespacedKey itemKey = new NamespacedKey(this, "staff_tool");
    private File stateFile;
    private YamlConfiguration state;
    private BukkitTask actionbarTask;

    @Override public void onEnable() {
        saveDefaultConfig();
        stateFile = new File(getDataFolder(), "state.yml");
        state = YamlConfiguration.loadConfiguration(stateFile);
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("staffmode")).setExecutor(this);
        Objects.requireNonNull(getCommand("staffmode")).setTabCompleter(this);
        Objects.requireNonNull(getCommand("staffmodeadmin")).setExecutor(this);
        recoverAfterRestart();
        startActionbarTask();
        setupLuckPerms();
        getLogger().info("FaridStaffMode enabled.");
    }

    @Override public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (staffMode.contains(p.getUniqueId())) disableStaffMode(p, true);
        }
        saveState();
        if (actionbarTask != null) actionbarTask.cancel();
    }

    private String msg(String path) { return color(getConfig().getString("MESSAGES." + path, "&cMissing message: " + path)); }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private boolean cfg(String path) { return getConfig().getBoolean("STAFF-MODE." + path); }
    private int slot(String path) { return getConfig().getInt("STAFF-MODE.HOTBAR-SLOTS." + path, -1); }
    private String perm(String path) { return getConfig().getString("STAFF-MODE." + path, "faridcore.staff.mode"); }
    private boolean allowed(Player p, String permission) {
        if (p.hasPermission(perm(permission)) || p.hasPermission("faridcore.admin.staffmode")) return true;
        p.sendMessage(msg("NO-PERMISSION")); return false;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("staffmodeadmin")) {
            if (!sender.hasPermission("faridcore.admin.staffmode")) { sender.sendMessage(msg("NO-PERMISSION")); return true; }
            if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig(); sender.sendMessage(msg("RELOAD-SUCCESS")); return true;
            }
            sender.sendMessage(color("&e/staffmodeadmin reload")); return true;
        }
        if (!(sender instanceof Player p)) { sender.sendMessage(msg("PLAYER-ONLY")); return true; }
        if (!cfg("ENABLED")) { p.sendMessage(msg("FEATURE-DISABLED")); return true; }
        if (!allowed(p, "STAFF-PERMISSION")) return true;
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!p.hasPermission("faridcore.admin.staffmode")) { p.sendMessage(msg("NO-PERMISSION")); return true; }
            reloadConfig(); p.sendMessage(msg("RELOAD-SUCCESS")); return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("off")) disableStaffMode(p, false);
        else if (staffMode.contains(p.getUniqueId())) disableStaffMode(p, false);
        else enableStaffMode(p);
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return args.length == 1 ? List.of("on", "off", "reload") : List.of();
    }

    private void enableStaffMode(Player p) {
        UUID id = p.getUniqueId();
        if (!staffMode.add(id)) return;
        savedContents.put(id, cloneItems(p.getInventory().getStorageContents()));
        savedArmor.put(id, cloneItems(p.getInventory().getArmorContents()));
        savedOffhand.put(id, p.getInventory().getItemInOffHand().clone());
        savedModes.put(id, p.getGameMode());
        savedFlight.put(id, p.getAllowFlight());
        savedWalk.put(id, p.getWalkSpeed());
        p.getInventory().clear(); p.getInventory().setArmorContents(null);
        p.getInventory().setItemInOffHand(null);
        p.setGameMode(GameMode.SURVIVAL);
        giveTools(p);
        p.sendMessage(msg("ENABLED"));
        p.sendActionBar(msg("ENABLED-ACTIONBAR"));
        if (cfg("AUTO-VANISH-ON-ENABLE") && allowedSilent(p, "VANISH-PERMISSION")) toggleVanish(p);
        saveState();
    }

    private void disableStaffMode(Player p, boolean shutdown) {
        UUID id = p.getUniqueId();
        if (!staffMode.remove(id)) return;
        if (vanished.contains(id)) toggleVanish(p);
        if (betterView.remove(id)) removeBetterView(p);
        if (spectator.remove(id)) p.setGameMode(savedModes.getOrDefault(id, GameMode.SURVIVAL));
        if (cfg("RESTORE-INVENTORY-ON-DISABLE")) {
            p.getInventory().clear();
            p.getInventory().setStorageContents(savedContents.getOrDefault(id, new ItemStack[36]));
            p.getInventory().setArmorContents(savedArmor.getOrDefault(id, new ItemStack[4]));
            p.getInventory().setItemInOffHand(savedOffhand.getOrDefault(id, new ItemStack(Material.AIR)));
        } else p.getInventory().clear();
        p.setGameMode(savedModes.getOrDefault(id, GameMode.SURVIVAL));
        p.setAllowFlight(savedFlight.getOrDefault(id, false));
        p.setFlying(false);
        p.setWalkSpeed(savedWalk.getOrDefault(id, 0.2f));
        savedContents.remove(id); savedArmor.remove(id); savedOffhand.remove(id);
        savedModes.remove(id); savedFlight.remove(id); savedWalk.remove(id);
        p.sendMessage(msg("DISABLED"));
        if (!shutdown) p.sendActionBar(msg("DISABLED-ACTIONBAR"));
        saveState();
    }

    private ItemStack[] cloneItems(ItemStack[] items) {
        ItemStack[] out = new ItemStack[items.length];
        for (int i=0;i<items.length;i++) out[i] = items[i] == null ? null : items[i].clone();
        return out;
    }

    private ItemStack makeItem(String section, String id) {
        String base = "ITEMS." + section;
        String path = base + (id == null ? "" : "." + id);
        Material material = Material.matchMaterial(getConfig().getString(path + ".MATERIAL", "STONE"));
        if (material == null) material = Material.STONE;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(getConfig().getString(path + ".NAME", section)));
        meta.setLore(getConfig().getStringList(path + ".LORE").stream().map(this::color).toList());
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, section + (id == null ? "" : ":" + id));
        item.setItemMeta(meta);
        return item;
    }

    private void putTool(Player p, int configuredSlot, ItemStack item) {
        if (configuredSlot >= 0 && configuredSlot <= 8) p.getInventory().setItem(configuredSlot, item);
    }

    private void giveTools(Player p) {
        var inv = p.getInventory();
        putTool(p, slot("VANISH"), makeItem("VANISH", vanished.contains(p.getUniqueId()) ? "ENABLED" : "DISABLED"));
        putTool(p, slot("FREEZE"), makeItem("FREEZE", null));
        putTool(p, slot("STAFF_LIST"), makeItem("STAFF_LIST", null));
        putTool(p, slot("BETTER_VIEW"), makeItem("BETTER_VIEW", null));
        putTool(p, slot("RANDOM_TELEPORT"), makeItem("RANDOM_TELEPORT", null));
        putTool(p, slot("SPECTATOR"), makeItem("SPECTATOR", spectator.contains(p.getUniqueId()) ? "ENABLED" : "DISABLED"));
        for (String key : getConfig().getConfigurationSection("CUSTOM-ITEMS") == null ? Set.<String>of() :
                getConfig().getConfigurationSection("CUSTOM-ITEMS").getKeys(false)) {
            String b = "CUSTOM-ITEMS." + key;
            if (!getConfig().getBoolean(b + ".ENABLED")) continue;
            String permission = getConfig().getString(b + ".PERMISSION", "");
            if (!permission.isEmpty() && !p.hasPermission(permission)) continue;
            int s = getConfig().getInt(b + ".SLOT", -1);
            if (s < 0 || s > 8 || inv.getItem(s) != null) continue;
            Material mat = Material.matchMaterial(getConfig().getString(b + ".MATERIAL", "STONE"));
            if (mat == null) mat = Material.STONE;
            ItemStack item = new ItemStack(mat); ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(color(getConfig().getString(b + ".NAME", key)));
            meta.setLore(getConfig().getStringList(b + ".LORE").stream().map(this::color).toList());
            meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, "CUSTOM:" + key);
            item.setItemMeta(meta); inv.setItem(s, item);
        }
    }

    private void toggleVanish(Player p) {
        // Delegate vanish to the server's /sv command as requested.
        Bukkit.dispatchCommand(p, "sv");
        UUID id = p.getUniqueId();
        if (vanished.contains(id)) vanished.remove(id); else vanished.add(id);
        if (staffMode.contains(id))
            p.getInventory().setItem(slot("VANISH"), makeItem("VANISH", vanished.contains(id) ? "ENABLED" : "DISABLED"));
        saveState();
    }

    private void fakeMessage(Player p, boolean join) {
        String text = join ? color("&e" + p.getName() + " joined the game") : color("&e" + p.getName() + " left the game");
        boolean onlyRegular = getConfig().getBoolean("STAFF-MODE.VANISH-FAKE-MESSAGES.ONLY-TO-REGULAR-PLAYERS", true);
        for (Player target : Bukkit.getOnlinePlayers())
            if (!onlyRegular || !target.hasPermission(perm("SEE-VANISHED-PERMISSION"))) target.sendMessage(text);
    }

    private void toggleBetterView(Player p) {
        if (!allowed(p, "BETTER-VIEW-PERMISSION")) return;
        if (betterView.add(p.getUniqueId())) {
            if (getConfig().getBoolean("STAFF-MODE.BETTER-VIEW.ENABLE-NIGHT-VISION"))
                p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false));
            if (getConfig().getBoolean("STAFF-MODE.BETTER-VIEW.ENABLE-FLIGHT")) {
                p.setAllowFlight(true);
                if (getConfig().getBoolean("STAFF-MODE.BETTER-VIEW.AUTO-FLY")) p.setFlying(true);
            }
            p.sendMessage(msg("BETTER-VIEW-ON"));
        } else { removeBetterView(p); p.sendMessage(msg("BETTER-VIEW-OFF")); }
    }
    private void removeBetterView(Player p) {
        p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        p.setFlying(false); p.setAllowFlight(savedFlight.getOrDefault(p.getUniqueId(), false));
    }

    private void toggleSpectator(Player p) {
        if (!allowed(p, "SPECTATOR-PERMISSION")) return;
        if (spectator.add(p.getUniqueId())) {
            p.setGameMode(GameMode.SPECTATOR); p.sendMessage(msg("SPECTATOR-ON"));
            p.getInventory().setItem(slot("SPECTATOR"), makeItem("SPECTATOR", "ENABLED"));
        } else {
            spectator.remove(p.getUniqueId()); p.setGameMode(savedModes.getOrDefault(p.getUniqueId(), GameMode.SURVIVAL));
            p.sendMessage(msg("SPECTATOR-OFF"));
            p.getInventory().setItem(slot("SPECTATOR"), makeItem("SPECTATOR", "DISABLED"));
        }
    }

    private void randomTeleport(Player p) {
        if (!allowed(p, "RANDOM-TELEPORT-PERMISSION")) return;
        // Deliberately execute the exact vanilla command requested by the server owner.
        Bukkit.dispatchCommand(p, "minecraft:tp @r");
    }

    private void freezeTarget(Player staff, Player target) {
        if (target.equals(staff)) { staff.sendMessage(color("&cYou cannot freeze yourself.")); return; }
        if (frozen.remove(target.getUniqueId())) {
            frozenLocations.remove(target.getUniqueId());
            target.sendMessage(color("&aYou have been unfrozen by staff."));
            staff.sendMessage(color("&aUnfroze " + target.getName() + "."));
        } else {
            frozen.add(target.getUniqueId()); frozenLocations.put(target.getUniqueId(), target.getLocation().clone());
            target.sendMessage(color("&bYou have been frozen by staff. Please wait for a staff member."));
            staff.sendMessage(color("&bFroze " + target.getName() + "."));
        }
    }

    @EventHandler public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!staffMode.contains(p.getUniqueId()) || e.getItem() == null || !e.getItem().hasItemMeta()) return;
        String tag = e.getItem().getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if (tag == null) return;
        e.setCancelled(true);
        if (tag.startsWith("CUSTOM:")) { runCustom(p, tag.substring(7), e); return; }
        switch (tag) {
            case "VANISH:ENABLED", "VANISH:DISABLED" -> {
                if (allowed(p, "VANISH-PERMISSION")) toggleVanish(p);
            }
            case "FREEZE" -> {
                if (e.getAction().isRightClick()) {
                    if (e.getClickedBlock() == null) return;
                    // Player targets are handled by EntityDamageByEntity-style interaction via ray trace below.
                    Player target = findTarget(p, 5);
                    if (target != null) freezeTarget(p, target);
                    else p.sendMessage(color("&cLook directly at a player and right-click."));
                } else if (e.getAction().isLeftClick()) openFrozenMenu(p);
            }
            case "STAFF_LIST" -> { if (allowed(p, "STAFF-LIST-PERMISSION")) openStaffMenu(p); }
            case "BETTER_VIEW" -> toggleBetterView(p);
            case "RANDOM_TELEPORT" -> randomTeleport(p);
            case "SPECTATOR:ENABLED", "SPECTATOR:DISABLED" -> toggleSpectator(p);
        }
    }

    private Player findTarget(Player p, int range) {
        var result = p.getWorld().rayTraceEntities(p.getEyeLocation(), p.getEyeLocation().getDirection(), range,
                0.6, entity -> entity instanceof Player && !entity.equals(p));
        return result != null && result.getHitEntity() instanceof Player target ? target : null;
    }

    private void runCustom(Player p, String key, PlayerInteractEvent event) {
        String b = "CUSTOM-ITEMS." + key;
        if (!getConfig().getBoolean(b + ".ENABLED")) return;
        String permission = getConfig().getString(b + ".PERMISSION", "");
        if (!permission.isEmpty() && !p.hasPermission(permission)) { p.sendMessage(msg("NO-PERMISSION")); return; }
        Player target = findTarget(p, 5);
        if (getConfig().getBoolean(b + ".REQUIRE-TARGET") && target == null) { p.sendMessage(msg("CUSTOM-ITEM-NO-TARGET")); return; }
        String mode = getConfig().getString(b + ".EXECUTE-AS", "PLAYER");
        for (String raw : getConfig().getStringList(b + ".COMMANDS")) {
            String cmd = raw.replace("{player}", p.getName()).replace("{player_uuid}", p.getUniqueId().toString())
                    .replace("{world}", p.getWorld().getName())
                    .replace("{target}", target == null ? "" : target.getName())
                    .replace("{target_uuid}", target == null ? "" : target.getUniqueId().toString());
            Bukkit.dispatchCommand(mode.equalsIgnoreCase("CONSOLE") ? Bukkit.getConsoleSender() : p, cmd);
        }
    }

    private void openStaffMenu(Player p) {
        int size = Math.max(9, Math.min(54, getConfig().getInt("MENUS.STAFF-LIST.SIZE", 54)));
        Inventory inv = Bukkit.createInventory(null, size, color(getConfig().getString("MENUS.STAFF-LIST.TITLE", "&8Online Staff")));
        fillMenu(inv, "STAFF-LIST");
        List<Player> list = Bukkit.getOnlinePlayers().stream().filter(x -> x.hasPermission(perm("STAFF-PERMISSION"))).toList();
        List<Integer> slots = getConfig().getIntegerList("MENUS.STAFF-LIST.CONTENT-SLOTS");
        int i=0;
        for (Player staff : list) {
            if (i >= slots.size()) break;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            var meta = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta(); meta.setOwningPlayer(staff);
            meta.setDisplayName(color("&a" + staff.getName()));
            meta.setLore(List.of(color("&7World: &f" + staff.getWorld().getName()), color("&7Click to teleport")));
            head.setItemMeta(meta); inv.setItem(slots.get(i++), head);
        }
        p.openInventory(inv);
    }

    private void openFrozenMenu(Player p) {
        int size = Math.max(9, Math.min(54, getConfig().getInt("MENUS.FROZEN-PLAYERS.SIZE", 54)));
        Inventory inv = Bukkit.createInventory(null, size, color(getConfig().getString("MENUS.FROZEN-PLAYERS.TITLE", "&8Frozen Players")));
        fillMenu(inv, "FROZEN-PLAYERS");
        List<Integer> slots = getConfig().getIntegerList("MENUS.FROZEN-PLAYERS.CONTENT-SLOTS"); int i=0;
        for (UUID id : frozen) {
            Player target = Bukkit.getPlayer(id); if (target == null || i >= slots.size()) continue;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            var meta = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta(); meta.setOwningPlayer(target);
            meta.setDisplayName(color("&b" + target.getName()));
            meta.setLore(List.of(color("&7Click to unfreeze")));
            head.setItemMeta(meta); inv.setItem(slots.get(i++), head);
        }
        p.openInventory(inv);
    }

    private void fillMenu(Inventory inv, String section) {
        String b = "MENUS." + section;
        Material pane = Material.matchMaterial(getConfig().getString(b + ".PLACEHOLDER-MATERIAL", "GRAY_STAINED_GLASS_PANE"));
        if (pane == null) pane = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack fill = new ItemStack(pane); ItemMeta fm = fill.getItemMeta(); fm.setDisplayName(" "); fill.setItemMeta(fm);
        for (int i=0;i<inv.getSize();i++) inv.setItem(i, fill);
        for (int s : getConfig().getIntegerList(b + ".CONTENT-SLOTS")) if (s>=0 && s<inv.getSize()) inv.setItem(s, null);
        int refresh = getConfig().getInt(b + ".REFRESH-SLOT", 49);
        if (refresh>=0 && refresh<inv.getSize()) {
            ItemStack item = new ItemStack(Material.SUNFLOWER); ItemMeta m=item.getItemMeta();
            m.setDisplayName(color("&eRefresh")); item.setItemMeta(m); inv.setItem(refresh,item);
        }
    }

    @EventHandler public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title.equals(color(getConfig().getString("MENUS.STAFF-LIST.TITLE", "&8Online Staff")))) {
            e.setCancelled(true);
            if (e.getCurrentItem() == null || e.getCurrentItem().getType() != Material.PLAYER_HEAD) return;
            String name = ChatColor.stripColor(e.getCurrentItem().getItemMeta().getDisplayName());
            Player target = Bukkit.getPlayerExact(name); if (target != null && p.hasPermission(perm("STAFF-LIST-PERMISSION"))) p.teleport(target);
        } else if (title.equals(color(getConfig().getString("MENUS.FROZEN-PLAYERS.TITLE", "&8Frozen Players")))) {
            e.setCancelled(true);
            if (e.getCurrentItem() == null || e.getCurrentItem().getType() != Material.PLAYER_HEAD) return;
            String name = ChatColor.stripColor(e.getCurrentItem().getItemMeta().getDisplayName());
            Player target = Bukkit.getPlayerExact(name); if (target != null) freezeTarget(p, target);
            Bukkit.getScheduler().runTask(this, () -> openFrozenMenu(p));
        }
    }

    @EventHandler public void onMove(PlayerMoveEvent e) {
        if (!frozen.contains(e.getPlayer().getUniqueId()) || e.getTo() == null) return;
        if (e.getFrom().getX()!=e.getTo().getX() || e.getFrom().getY()!=e.getTo().getY() || e.getFrom().getZ()!=e.getTo().getZ()) {
            Location lock = frozenLocations.getOrDefault(e.getPlayer().getUniqueId(), e.getFrom());
            e.setTo(new Location(lock.getWorld(), lock.getX(), e.getTo().getY(), lock.getZ(), e.getTo().getYaw(), e.getTo().getPitch()));
        }
    }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) {
        if (frozen.contains(e.getPlayer().getUniqueId()) && !e.getPlayer().hasPermission("faridcore.admin.staffmode")) e.setCancelled(true);
    }
    @EventHandler public void onFrozenCommand(PlayerCommandPreprocessEvent e) {
        if (frozen.contains(e.getPlayer().getUniqueId()) && !e.getPlayer().hasPermission("faridcore.admin.staffmode")) {
            String command = e.getMessage().toLowerCase(Locale.ROOT);
            if (!command.startsWith("/msg ") && !command.startsWith("/tell ") && !command.startsWith("/helpop")) {
                e.setCancelled(true); e.getPlayer().sendMessage(color("&cYou are frozen. Please wait for staff."));
            }
        }
    }
    @EventHandler public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && frozen.contains(p.getUniqueId())) e.setCancelled(true);
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p=e.getPlayer(); UUID id=p.getUniqueId();
        if (staffMode.contains(id) && cfg("PERSIST-ON-QUIT")) savePlayerSnapshot(p);
        frozen.remove(id); frozenLocations.remove(id);
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p=e.getPlayer();
        if (staffMode.contains(p.getUniqueId())) Bukkit.getScheduler().runTask(this, () -> {
            if (cfg("PERSIST-ON-QUIT")) { p.getInventory().clear(); giveTools(p); }
        });
        for (Player v : Bukkit.getOnlinePlayers()) if (vanished.contains(v.getUniqueId()) && !p.hasPermission(perm("SEE-VANISHED-PERMISSION"))) p.hidePlayer(this,v);
    }
    @EventHandler public void onDrop(PlayerDropItemEvent e) {
        if (staffMode.contains(e.getPlayer().getUniqueId()) && cfg("LOCK-TOOLS")) e.setCancelled(true);
    }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) {
        if (staffMode.contains(e.getPlayer().getUniqueId()) && cfg("LOCK-TOOLS")) e.setCancelled(true);
    }
    @EventHandler public void onHeld(PlayerItemHeldEvent e) {
        if (staffMode.contains(e.getPlayer().getUniqueId()) && cfg("LOCK-TOOLS")) {
            // Hotbar tools are intentionally locked in place; selecting remains allowed.
        }
    }

    private void savePlayerSnapshot(Player p) {
        UUID id=p.getUniqueId();
        state.set("players."+id+".contents", Arrays.asList(cloneItems(p.getInventory().getStorageContents())));
        state.set("players."+id+".armor", Arrays.asList(cloneItems(p.getInventory().getArmorContents())));
        state.set("players."+id+".offhand", p.getInventory().getItemInOffHand());
        state.set("players."+id+".gamemode", p.getGameMode().name());
        saveState();
    }

    private void recoverAfterRestart() {
        if (!cfg("PERSIST-ON-RESTART")) return;
        if (state.getConfigurationSection("players") == null) return;
        for (String key : state.getConfigurationSection("players").getKeys(false)) {
            UUID id; try { id=UUID.fromString(key); } catch (Exception ex) { continue; }
            Player p=Bukkit.getPlayer(id); if (p==null) continue;
            List<?> contents=state.getList("players."+key+".contents");
            if (contents!=null) {
                ItemStack[] items=contents.stream().map(x -> x instanceof ItemStack it ? it : null).toArray(ItemStack[]::new);
                p.getInventory().setStorageContents(items);
            }
            List<?> armor=state.getList("players."+key+".armor");
            if (armor!=null) p.getInventory().setArmorContents(armor.stream().map(x -> x instanceof ItemStack it ? it : null).toArray(ItemStack[]::new));
            p.sendMessage(msg("RECOVERED-AFTER-RESTART"));
            state.set("players."+key, null);
        }
        saveState();
    }

    private void saveState() {
        state.set("active", staffMode.stream().map(UUID::toString).toList());
        state.set("vanished", vanished.stream().map(UUID::toString).toList());
        try { state.save(stateFile); } catch (IOException ex) { getLogger().severe("Cannot save state.yml: "+ex.getMessage()); }
    }

    private void startActionbarTask() {
        actionbarTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!getConfig().getBoolean("STAFF-MODE.VANISH-ACTIONBAR.ENABLED")) return;
            for (Player p : Bukkit.getOnlinePlayers()) if (vanished.contains(p.getUniqueId()))
                p.sendActionBar(color(getConfig().getString("STAFF-MODE.VANISH-ACTIONBAR.MESSAGE", "&aVANISHED")));
        }, 0L, Math.max(1, getConfig().getLong("STAFF-MODE.VANISH-ACTIONBAR.INTERVAL-TICKS", 40)));
    }

    private void setupLuckPerms() {
        if (!getConfig().getBoolean("STAFF-MODE.LUCKPERMS-CONTEXT.ENABLED") || !Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) return;
        RegisteredServiceProvider<LuckPerms> provider = getServer().getServicesManager().getRegistration(LuckPerms.class);
        if (provider == null) return;
        LuckPerms lp=provider.getProvider();
        String key=getConfig().getString("STAFF-MODE.LUCKPERMS-CONTEXT.KEY","staffmode");
        lp.getContextManager().registerCalculator(new ContextCalculator<Player>() {
            @Override public void calculate(Player target, ContextConsumer consumer) {
                consumer.accept(key, Boolean.toString(staffMode.contains(target.getUniqueId())));
            }
            @Override public boolean estimatePotentialContexts(ContextConsumer consumer) {
                consumer.accept(key, "true");
                consumer.accept(key, "false");
                return true;
            }
        });
    }

    private boolean allowedSilent(Player p, String permission) { return p.hasPermission(perm(permission)) || p.hasPermission("faridcore.admin.staffmode"); }
}
